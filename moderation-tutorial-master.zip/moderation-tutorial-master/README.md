# Discord Bot Slash Commands Tutorial + Moderation Commands

See full tutorial video [here](https://youtu.be/HHNLSow5p5c)

## Content

- Slash Command handler with permission handler
- Slash Command loading & deploying
- Timeout command
- Kick command
- Ban command

## Commands
**Start the bot**

`node index.js`

**Deploy slash commands**

`node loadslash.js`